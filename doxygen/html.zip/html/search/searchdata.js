var indexSectionsWithContent =
{
  0: "_abcdefilmprstuv",
  1: "_",
  2: "c",
  3: "abcdefilmprstv",
  4: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Определения типов"
};

