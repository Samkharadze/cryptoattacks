var searchData=
[
  ['s_5fmatrix',['s_matrix',['../choph_8cpp.html#aa55f5557fa0e92b71bc73e28225f15d3',1,'choph.cpp']]],
  ['substitute_5fbreak',['substitute_break',['../choph_8cpp.html#a427f14fb678ee255afc52fd7e0d6975e',1,'choph.cpp']]],
  ['substitute_5fdecrypt',['substitute_decrypt',['../choph_8cpp.html#a9c53a049332fae6cdfad786bf4eeea11',1,'choph.cpp']]],
  ['substitute_5fencrypt',['substitute_encrypt',['../choph_8cpp.html#a3a6c1ce5c2f56412885a40fcd2bc8e86',1,'choph.cpp']]],
  ['substitute_5fgenerate_5fkey',['substitute_generate_key',['../choph_8cpp.html#acad9c4fabb6634dc5ef1416c7c834757',1,'choph.cpp']]]
];
