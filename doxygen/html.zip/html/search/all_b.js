var searchData=
[
  ['recovervigenerekey',['recovervigenerekey',['../choph_8cpp.html#af1c6b7a014d3a7ac4733b768901ae446',1,'choph.cpp']]],
  ['rip',['rip',['../choph_8cpp.html#a9ed46a7091b0ec3c8169cb8c0513692b',1,'choph.cpp']]]
];
