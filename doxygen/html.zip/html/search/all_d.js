var searchData=
[
  ['trigram_5fcount',['trigram_count',['../choph_8cpp.html#ab84334abaf3c4ee10870aab4a92031c9',1,'choph.cpp']]],
  ['trigram_5ffit',['trigram_fit',['../choph_8cpp.html#aafef85ef482b36718e0e0f7de6681ab1',1,'choph.cpp']]],
  ['trigram_5ffreq',['trigram_freq',['../choph_8cpp.html#aa5cc96c7e3b1423aa78b9508c2c1a74c',1,'choph.cpp']]]
];
